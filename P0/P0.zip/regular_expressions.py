"""
Esta es la expresion regular para el ejercicio 0, que se facilita
a modo de ejemplo:
"""
RE0 = "[ab]*a"

"""
Completa a continuacion las expresiones regulares para los
ejercicios 1-6:
"""
RE1 = ""
RE2 = ""
RE3 = ""
RE4 = ""
RE5 = ""
RE6 = ""

"""
Recuerda que puedes usar el fichero test_p0.py para probar tus
expresiones regulares.
"""

